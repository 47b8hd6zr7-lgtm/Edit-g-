"""
pipeline.py - The real engine. Takes raw footage + a template name, and
produces a finished, edited video:
  1. Detects dead air and removes it (cuts.py)
  2. Analyzes motion to decide slow-mo / fast-mo segments (motion.py)
  3. Analyzes color and applies template grade (color.py)
  4. Builds one ffmpeg filter_complex that trims, speed-ramps, concatenates,
     color-grades, and (optionally) burns captions - in a single render pass.
"""
import os
import subprocess
import tempfile

from cuts import build_keep_segments
from motion import analyze_motion, classify_windows, merge_adjacent
from color import auto_levels, build_eq_filter
from templates import get_template


def _intersect(a_start, a_end, b_start, b_end):
    s = max(a_start, b_start)
    e = min(a_end, b_end)
    return (s, e) if e > s else None


def _split_segment_by_motion(seg_start, seg_end, motion_segments):
    """Splits one 'keep' segment into sub-segments tagged with an effect,
    based on overlap with the classified motion windows."""
    pieces = []
    cursor = seg_start
    for m in sorted(motion_segments, key=lambda x: x["start"]):
        overlap = _intersect(seg_start, seg_end, m["start"], m["end"])
        if not overlap:
            continue
        o_start, o_end = overlap
        if o_start > cursor:
            pieces.append((cursor, o_start, "normal"))
        pieces.append((o_start, o_end, m["effect"]))
        cursor = o_end
    if cursor < seg_end:
        pieces.append((cursor, seg_end, "normal"))
    # merge tiny slivers into neighbors (avoid ffmpeg choking on <0.05s clips)
    cleaned = [p for p in pieces if p[1] - p[0] > 0.08]
    return cleaned if cleaned else [(seg_start, seg_end, "normal")]


def _atempo_chain(factor):
    """atempo filter only supports 0.5-2.0 per instance; chain multiple
    instances to reach factors outside that range."""
    filters = []
    f = factor
    if f < 0.5:
        while f < 0.5:
            filters.append("atempo=0.5")
            f /= 0.5
        filters.append(f"atempo={round(f, 3)}")
    elif f > 2.0:
        while f > 2.0:
            filters.append("atempo=2.0")
            f /= 2.0
        filters.append(f"atempo={round(f, 3)}")
    else:
        filters.append(f"atempo={round(f, 3)}")
    return ",".join(filters)


def build_final_segments(video_path, template):
    keep = build_keep_segments(
        video_path, noise_db=template["silence_sensitivity"]
    )
    windows, _duration = analyze_motion(video_path)
    classified = classify_windows(
        windows,
        slomo_percentile=template["slomo_percentile"],
        fastmo_percentile=template["fastmo_percentile"],
    )
    merged_motion = merge_adjacent(classified)

    final_segments = []
    for seg_start, seg_end in keep:
        pieces = _split_segment_by_motion(seg_start, seg_end, merged_motion)
        for p_start, p_end, effect in pieces:
            if effect == "slomo":
                speed = template["slomo_speed"]
            elif effect == "fastmo":
                speed = template["fastmo_speed"]
            else:
                speed = 1.0
            final_segments.append((p_start, p_end, speed, effect))
    return final_segments


def render(video_path, template_name, output_path, srt_path=None, max_segments=60):
    template = get_template(template_name)
    segments = build_final_segments(video_path, template)

    # Safety cap: extremely choppy footage could produce hundreds of tiny
    # segments, which would make the ffmpeg filter graph unmanageable.
    if len(segments) > max_segments:
        segments = segments[:max_segments]

    auto = auto_levels(video_path)
    eq_filter = build_eq_filter(auto, template["color_grade"])

    filter_parts = []
    concat_v = []
    concat_a = []

    for i, (start, end, speed, effect) in enumerate(segments):
        v_label = f"v{i}"
        a_label = f"a{i}"
        filter_parts.append(
            f"[0:v]trim=start={start:.3f}:end={end:.3f},setpts=PTS-STARTPTS,"
            f"setpts={1/speed:.4f}*PTS[{v_label}]"
        )
        atempo = _atempo_chain(speed)
        filter_parts.append(
            f"[0:a]atrim=start={start:.3f}:end={end:.3f},asetpts=PTS-STARTPTS,"
            f"{atempo}[{a_label}]"
        )
        concat_v.append(f"[{v_label}]")
        concat_a.append(f"[{a_label}]")

    n = len(segments)
    concat_str = "".join(concat_v[i] + concat_a[i] for i in range(n))
    filter_parts.append(f"{concat_str}concat=n={n}:v=1:a=1[vconcat][aout]")
    filter_parts.append(f"[vconcat]{eq_filter}[vgraded]")

    final_video_label = "vgraded"
    if srt_path and os.path.exists(srt_path):
        style = template["caption_style"]
        force_style = (
            f"FontName={style['font']},FontSize={style['size']},"
            f"PrimaryColour={style['color']},OutlineColour={style['outline_color']}"
        )
        srt_escaped = srt_path.replace(":", "\\:")
        filter_parts.append(
            f"[vgraded]subtitles='{srt_escaped}':force_style='{force_style}'[vcap]"
        )
        final_video_label = "vcap"

    filter_complex = ";".join(filter_parts)

    cmd = [
        "ffmpeg", "-y", "-i", video_path,
        "-filter_complex", filter_complex,
        "-map", f"[{final_video_label}]", "-map", "[aout]",
        "-c:v", "libx264", "-preset", "fast", "-crf", "20",
        "-c:a", "aac",
        output_path,
    ]

    result = subprocess.run(cmd, capture_output=True, text=True)
    return {
        "success": result.returncode == 0,
        "segments_used": len(segments),
        "effects_applied": {
            "slomo": sum(1 for s in segments if s[3] == "slomo"),
            "fastmo": sum(1 for s in segments if s[3] == "fastmo"),
            "normal": sum(1 for s in segments if s[3] == "normal"),
        },
        "stderr_tail": result.stderr[-1500:] if result.returncode != 0 else None,
        "output_path": output_path if result.returncode == 0 else None,
    }
