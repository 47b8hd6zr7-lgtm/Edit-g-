"""
app.py - The web API. Upload raw footage + pick a template, get back the
auto-edited video. This is the real backend, not a demo stub - it calls the
same pipeline.render() that was tested end-to-end.
"""
import os
import uuid

from flask import Flask, request, jsonify, send_file
from flask_cors import CORS

from pipeline import render
from templates import TEMPLATES

UPLOAD_DIR = "/tmp/autoeditor_uploads"
OUTPUT_DIR = "/tmp/autoeditor_outputs"
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

app = Flask(__name__)
CORS(app)

MAX_UPLOAD_MB = 300
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_MB * 1024 * 1024


@app.route("/api/templates", methods=["GET"])
def list_templates():
    return jsonify([
        {"id": key, "label": t["label"], "description": t["description"]}
        for key, t in TEMPLATES.items()
    ])


@app.route("/api/edit", methods=["POST"])
def edit_video():
    if "video" not in request.files:
        return jsonify({"error": "No video file uploaded"}), 400

    file = request.files["video"]
    template_name = request.form.get("template", "energetic")
    if template_name not in TEMPLATES:
        return jsonify({"error": f"Unknown template: {template_name}"}), 400

    job_id = str(uuid.uuid4())
    input_path = os.path.join(UPLOAD_DIR, f"{job_id}_raw.mp4")
    output_path = os.path.join(OUTPUT_DIR, f"{job_id}_edited.mp4")
    file.save(input_path)

    try:
        result = render(input_path, template_name, output_path)
    except Exception as e:
        return jsonify({"error": f"Processing failed: {str(e)}"}), 500
    finally:
        if os.path.exists(input_path):
            os.remove(input_path)

    if not result["success"]:
        return jsonify({"error": "Video processing failed", "detail": result.get("stderr_tail")}), 500

    return jsonify({
        "job_id": job_id,
        "download_url": f"/api/download/{job_id}",
        "effects_applied": result["effects_applied"],
    })


@app.route("/api/download/<job_id>", methods=["GET"])
def download(job_id):
    path = os.path.join(OUTPUT_DIR, f"{job_id}_edited.mp4")
    if not os.path.exists(path):
        return jsonify({"error": "Not found"}), 404
    return send_file(path, mimetype="video/mp4", as_attachment=True,
                      download_name="edited_video.mp4")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
